<th {{ $attributes->merge(['class' => 'py-2 px-4 bg-base-50 font-bold uppercase text-sm text-left']) }}>
    {{ $slot }}
</th>