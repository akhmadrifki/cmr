<td {{ $attributes->merge(['class' => 'p-4']) }}>
    {{ $slot }}
</td>