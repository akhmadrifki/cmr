<table {{ $attributes->merge(['class' => 'table']) }}>
    <thead>
        {{ $head }}
    </thead>

    <tbody>
        {{ $body }}
    </tbody>
</table>