<div class="flex flex-row-reverse d-print-none with-border">
    <a href="{{ $href }}" class="btn btn-primary">{{ $slot }}</a>
</div>